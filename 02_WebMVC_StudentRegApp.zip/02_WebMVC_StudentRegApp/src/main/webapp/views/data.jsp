<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
    <h1>Students List</h1>

    <a href="/">Add New Students</a>
    <table border="1">
        <thead>
            <tr>
                <th>Sr. No</th>
                <th>Name</th>
                <th>Email</th>
                <th>Gender</th>
                <th>Course</th>
                <th>Timings</th>
            </tr>
        </thead>
        <tbody>
            <%-- Fixed the case sensitivity here from c:foreach to c:forEach --%>
            <c:forEach items="${students}" var="student" varStatus="index">
                <tr>
                    <td>${index.count}</td>
                    <td>${student.name}</td>
                    <td>${student.email}</td>
                    <td>${student.gender}</td>
                    <td>${student.course}</td>
                    <td>${student.timings}</td>
                </tr>
            </c:forEach>
        </tbody>
    </table>
</body>
</html>
