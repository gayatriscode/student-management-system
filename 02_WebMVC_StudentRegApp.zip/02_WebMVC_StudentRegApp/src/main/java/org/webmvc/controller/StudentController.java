package org.webmvc.controller;


import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.webmvc.binding.Student;
import org.webmvc.entity.StudentEntity;
import org.webmvc.repository.StudentRepository;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Controller
public class StudentController {

    @Autowired
    private StudentRepository studentRepository;

    //TODO- Method to load the student registration form
    @GetMapping("/")
    public String loadForm(Model model) {
        extracted(model);

        return "index";
    }

    private static void extracted(Model model) {
        List<String> courses = new ArrayList<String>();
        courses.add("Java");
        courses.add("Python");
        courses.add("C#");
        courses.add("JavaScript");
        courses.add("C++");
        courses.add("Go");
        courses.add("PHP");
        courses.add("DevOps");
        courses.add("AWS");

        List<String> timings = new ArrayList<String>();
        timings.add("Morning");
        timings.add("Afternoon");
        timings.add("Evening");
        timings.add("Night");

        Student student = new Student();

        model.addAttribute("courses", courses);
        model.addAttribute("timings", timings);
        model.addAttribute("student", student);
    }

    //TODO- Method to save student registration form data
    @PostMapping("/save")
    public String handleSubmit(Student student1, Model model) {
        System.out.println(student1);
        //logic to save
        StudentEntity studentEntity = new StudentEntity();
        //copy data from binding obj to entity obj
        BeanUtils.copyProperties(student1, studentEntity);
        studentEntity.setTimings(Arrays.toString(student1.getTimings()));
        studentRepository.save(studentEntity);

        extracted(model);

        model.addAttribute("msg", "Student Saved Successfully");

        return "index";
    }


    //TODO- Method to display student saved data

    @GetMapping("/viewStudents")
    public String getStudentsData(Model model) {
        List<StudentEntity> studentEntities = studentRepository.findAll();
        model.addAttribute("students", studentEntities);
        return "data";

    }

}
